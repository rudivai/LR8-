﻿#include <iostream>
#include "LeapYearModule.h"
#include "SegmentsModule.h"
#include "PointQuadrantModule.h"
using namespace std;

/// Вивід текстового меню для користувача
void ShowMenu() {
    std::cout << "\n========== MENU ==========\n";
    std::cout << "1. Leap year check (Task 1)\n";
    std::cout << "2. Calculate product of segments AC and BC (Task 2A)\n";
    std::cout << "3. Coordinate quadrant check (II or III) (Task 2B)\n";
    std::cout << "0. Exit\n";
    std::cout << "==========================\n";
    std::cout << "Your choice: ";
}

int main() {
    int choice;

    // Main menu loop: runs until user selects 0
    do {
        ShowMenu();
        std::cin >> choice;

        switch (choice) {
        case 1:
            std::cout << "\n--- Task 1: Leap Year ---\n";
            RunLeapYearTest();
            break;

        case 2:
            std::cout << "\n--- Task 2A: Segments AC and BC ---\n";
            RunSegmentTest();
            break;

        case 3:
            std::cout << "\n--- Task 2B: Coordinate Quadrant ---\n";
            RunPointTest();
            break;

        case 0:
            std::cout << "Program terminated.\n";
            break;

        default:
            std::cout << "Invalid choice! Please try again.\n";
        }

    } while (choice != 0);

    return 0;
}
    