﻿#include <iostream>     // Для вводу/виводу
#include <string>       // Для роботи з std::string
#include <cstring>      // Для роботи з функціями C-рядків (strcpy_s)
#include "task1.h"      // Заголовок з функціями завдання 1
#include "task2.h"      // Заголовок з функціями завдання 2

using namespace std;

// --- Функція виконання завдання 1 ---
// Демонструє роботу як стандартного методу string::replace, так і власноруч реалізованої функції
void run_task1() {
    string str1;
    cout << "Enter string: ";
    getline(cin, str1);  // Зчитуємо весь рядок з пробілами

    // Копіюємо string у C-style масив символів
    char str2[1024];  // Буфер для C-style рядка
    strcpy_s(str2, str1.c_str());  // Безпечне копіювання рядка у масив

    size_t pos, len;
    string replacement;

    // Зчитування параметрів для заміни
    cout << "Enter position to replace: ";
    cin >> pos;
    cout << "Enter length to replace: ";
    cin >> len;
    cout << "Enter replacement text: ";
    cin.ignore();  // Очищаємо буфер після cin
    getline(cin, replacement);  // Зчитуємо текст заміни

    // --- Заміна в std::string ---
    string str1_copy = str1;  // Робимо копію, щоб не змінювати оригінал
    string_replace_std(str1_copy, pos, len, replacement.c_str());
    cout << "Result using std::string::replace: " << str1_copy << "\n";

    // --- Заміна в C-style рядку ---
    string_replace_custom(str2, pos, len, replacement.c_str());
    cout << "Result using custom replace: " << str2 << "\n";
}

// --- Функція виконання завдання 2 ---
// Працює з підрядками між пробілами та обробляє файл input.txt
void run_task2() {
    string str;
    cout << "Enter string with spaces: ";
    getline(cin, str);

    // Перевіряємо наявність пробілів і обробляємо
    if (has_spaces(str)) {
        cout << "Substring between first and last space: " << extract_between_spaces(str) << "\n";
    }
    else {
        cout << "Not enough spaces to extract.\n";
    }

    // Обробляємо рядки з файлу та записуємо результат
    process_file_lines("input.txt", "output.txt");
    cout << "File processed. Check output.txt.\n";
}

// --- Точка входу: головне меню ---
int main() {
    int choice;
    do {
        // Меню користувача
        cout << "\nMenu:\n"
            << "1. Task 1 - Replace substring\n"
            << "2. Task 2 - Substring between spaces\n"
            << "0. Exit\n"
            << "Your choice: ";
        cin >> choice;
        cin.ignore();  // Очищаємо буфер після вводу числа

        // Виконуємо обраний пункт меню
        switch (choice) {
        case 1: run_task1(); break;
        case 2: run_task2(); break;
        case 0: cout << "Exiting.\n"; break;
        default: cout << "Invalid choice.\n";
        }

    } while (choice != 0);  // Поки не вибрано вихід

    return 0;
}